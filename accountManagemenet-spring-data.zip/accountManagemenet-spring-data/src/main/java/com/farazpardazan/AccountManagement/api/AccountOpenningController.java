package com.farazpardazan.AccountManagement.api;

import com.farazpardazan.AccountManagement.beans.Account;
import com.farazpardazan.AccountManagement.beans.AccountOpening;
import com.farazpardazan.AccountManagement.beans.AccountOpeningReply;
import com.farazpardazan.AccountManagement.enums.ActionStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AccountOpenningController {
    @RequestMapping(method = RequestMethod.POST, value="/open/account")

    @ResponseBody
    public AccountOpeningReply OpenAccount (@RequestBody Account account){
        AccountOpeningReply reply = new AccountOpeningReply();
        AccountOpening.getInstance().openAccount(account);
        reply.setName(account.getName());
        reply.setCurrencyType(account.getCurrencyType());
        reply.setAccountNO(account.getAccountNO());
        reply.setAccountOpeningActionStatus(ActionStatus.Successful);
        reply.setBalance(account.getBalance());

        return reply;
    }
}
