package com.farazpardazan.AccountManagement.api;

import com.farazpardazan.AccountManagement.beans.Account;
import com.farazpardazan.AccountManagement.beans.AccountOpening;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

@Controller
public class AccountRetrieveController {
    @RequestMapping(method = RequestMethod.GET, value="/account/allAccounts")

    @ResponseBody
    public Map<String, Account> getAllAccounts(){
        return AccountOpening.getInstance().getAllAccounts();
    }
}
