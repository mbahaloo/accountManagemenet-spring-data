package com.farazpardazan.AccountManagement.beans;

import com.farazpardazan.AccountManagement.enums.CCY;
import com.farazpardazan.AccountManagement.enums.ActionStatus;

public class AccountOpeningReply {
    private String name;
    private String accountNO;
    private int balance;
    private CCY currencyType;
    private ActionStatus accountOpeningActionStatus;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccountNO() {
        return accountNO;
    }

    public void setAccountNO(String accountNO) {
        this.accountNO = accountNO;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public CCY getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(CCY currencyType) {
        this.currencyType = currencyType;
    }

    public ActionStatus getAccountOpeningActionStatus() {
        return accountOpeningActionStatus;
    }

    public void setAccountOpeningActionStatus(ActionStatus accountOpeningActionStatus) {
        this.accountOpeningActionStatus = accountOpeningActionStatus;
    }
}
