package com.farazpardazan.AccountManagement.enums;

public enum CCY {
    rial,
    dollar
}
