package com.farazpardazan.AccountManagement.repository;

import com.farazpardazan.AccountManagement.beans.Account;
import org.springframework.data.repository.CrudRepository;

import javax.validation.constraints.Null;
import java.util.List;

public interface AccountRepository extends CrudRepository<Account, Long> {
    public List<Account> findAccountByName(String name);
    public Account findAccountById(Long id);
    public Account findAccountByAccountNO(String accountNO);
}
